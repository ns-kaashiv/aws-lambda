from flask import Flask, redirect, render_template, request, url_for
import aws_lambda_wsgi

app = Flask(__name__, static_folder="static")

@app.route("/", methods=["GET"])
def home():
    return render_template("index.html")

@app.route("/about", methods=["GET"])
def about():
    return render_template("about.html")

@app.route("/contact", methods=["GET"])
def contact():
    return render_template("contact.html")

@app.route("/shop-single", methods=["GET"])
def shop_single():
    return render_template("shop-single.html")

@app.route("/shop", methods=["GET"])
def shop():
    return render_template("shop.html")

def lambda_handler(event, context):
    return aws_lambda_wsgi.response(app, event, context)
